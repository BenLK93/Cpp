/****************************************************************************
** Meta object code from reading C++ file 'mainForm.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainForm.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainForm.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_mainForm_t {
    QByteArrayData data[22];
    char stringdata0[180];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_mainForm_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_mainForm_t qt_meta_stringdata_mainForm = {
    {
QT_MOC_LITERAL(0, 0, 8), // "mainForm"
QT_MOC_LITERAL(1, 9, 5), // "Push1"
QT_MOC_LITERAL(2, 15, 0), // ""
QT_MOC_LITERAL(3, 16, 5), // "Push2"
QT_MOC_LITERAL(4, 22, 5), // "Push3"
QT_MOC_LITERAL(5, 28, 5), // "Push4"
QT_MOC_LITERAL(6, 34, 5), // "Push5"
QT_MOC_LITERAL(7, 40, 5), // "Push6"
QT_MOC_LITERAL(8, 46, 5), // "Push7"
QT_MOC_LITERAL(9, 52, 5), // "Push8"
QT_MOC_LITERAL(10, 58, 5), // "Push9"
QT_MOC_LITERAL(11, 64, 5), // "Push0"
QT_MOC_LITERAL(12, 70, 11), // "PushDecimal"
QT_MOC_LITERAL(13, 82, 9), // "PushMinus"
QT_MOC_LITERAL(14, 92, 11), // "PushRacunaj"
QT_MOC_LITERAL(15, 104, 8), // "PushPlus"
QT_MOC_LITERAL(16, 113, 8), // "PushDeli"
QT_MOC_LITERAL(17, 122, 9), // "PushMnozi"
QT_MOC_LITERAL(18, 132, 8), // "PushCopy"
QT_MOC_LITERAL(19, 141, 9), // "PushPaste"
QT_MOC_LITERAL(20, 151, 14), // "PushSaveMemory"
QT_MOC_LITERAL(21, 166, 13) // "PushOutMemory"

    },
    "mainForm\0Push1\0\0Push2\0Push3\0Push4\0"
    "Push5\0Push6\0Push7\0Push8\0Push9\0Push0\0"
    "PushDecimal\0PushMinus\0PushRacunaj\0"
    "PushPlus\0PushDeli\0PushMnozi\0PushCopy\0"
    "PushPaste\0PushSaveMemory\0PushOutMemory"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_mainForm[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      20,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  114,    2, 0x08 /* Private */,
       3,    0,  115,    2, 0x08 /* Private */,
       4,    0,  116,    2, 0x08 /* Private */,
       5,    0,  117,    2, 0x08 /* Private */,
       6,    0,  118,    2, 0x08 /* Private */,
       7,    0,  119,    2, 0x08 /* Private */,
       8,    0,  120,    2, 0x08 /* Private */,
       9,    0,  121,    2, 0x08 /* Private */,
      10,    0,  122,    2, 0x08 /* Private */,
      11,    0,  123,    2, 0x08 /* Private */,
      12,    0,  124,    2, 0x08 /* Private */,
      13,    0,  125,    2, 0x08 /* Private */,
      14,    0,  126,    2, 0x08 /* Private */,
      15,    0,  127,    2, 0x08 /* Private */,
      16,    0,  128,    2, 0x08 /* Private */,
      17,    0,  129,    2, 0x08 /* Private */,
      18,    0,  130,    2, 0x08 /* Private */,
      19,    0,  131,    2, 0x08 /* Private */,
      20,    0,  132,    2, 0x08 /* Private */,
      21,    0,  133,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void mainForm::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        mainForm *_t = static_cast<mainForm *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->Push1(); break;
        case 1: _t->Push2(); break;
        case 2: _t->Push3(); break;
        case 3: _t->Push4(); break;
        case 4: _t->Push5(); break;
        case 5: _t->Push6(); break;
        case 6: _t->Push7(); break;
        case 7: _t->Push8(); break;
        case 8: _t->Push9(); break;
        case 9: _t->Push0(); break;
        case 10: _t->PushDecimal(); break;
        case 11: _t->PushMinus(); break;
        case 12: _t->PushRacunaj(); break;
        case 13: _t->PushPlus(); break;
        case 14: _t->PushDeli(); break;
        case 15: _t->PushMnozi(); break;
        case 16: _t->PushCopy(); break;
        case 17: _t->PushPaste(); break;
        case 18: _t->PushSaveMemory(); break;
        case 19: _t->PushOutMemory(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject mainForm::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_mainForm.data,
      qt_meta_data_mainForm,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *mainForm::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *mainForm::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_mainForm.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int mainForm::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 20)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 20;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 20)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 20;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
